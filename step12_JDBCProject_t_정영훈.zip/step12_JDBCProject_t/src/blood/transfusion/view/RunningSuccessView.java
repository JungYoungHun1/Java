package blood.transfusion.view;

public class RunningSuccessView {
	public static void showSuccess(String project) {
		System.out.println(project);
	}
}
